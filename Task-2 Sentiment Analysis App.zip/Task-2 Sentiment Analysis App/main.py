import json
import flask
from flask import Flask, request, app, jsonify, url_for, render_template
from transformers import AutoModelForSequenceClassification
from transformers import TFAutoModelForSequenceClassification
from transformers import AutoTokenizer, AutoConfig
from scipy.special import softmax
import numpy as np
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('Index.html')

# Preprocess text (username and link placeholders)
# def preprocess(text):
#     new_text = []
#     for t in text.split(" "):
#         t = '@user' if t.startswith('@') and len(t) > 1 else t
#         t = 'http' if t.startswith('http') else t
#         new_text.append(t)
#     return " ".join(new_text)
MODEL = "cardiffnlp/twitter-roberta-base-sentiment-latest"
#MODEL="bert-base-cased"
tokenizer = AutoTokenizer.from_pretrained(MODEL)
config = AutoConfig.from_pretrained(MODEL)
# PT
model = AutoModelForSequenceClassification.from_pretrained(MODEL)
# text = "he is good"
# #text = preprocess(text)
# encoded_input = tokenizer(text, return_tensors='pt')
# output = model(**encoded_input)
# scores = output[0][0].detach().numpy()
# scores = softmax(scores)

# @app.route('/predict_api', methods=['POST'])
# def predict_api():
#     review = request.args.get['sentence']
    #print(data)
# # TF
# model = TFAutoModelForSequenceClassification.from_pretrained(MODEL)
# model.save_pretrained(MODEL)
# text = "he is bad at learning good things"
# encoded_input = tokenizer(text, return_tensors='tf')
# output = model(encoded_input)
# scores = output[0][0].numpy()
# scores = softmax(scores)
# Print labels and scores
# ranking = np.argsort(scores)
# ranking = ranking[::-1]
# print(ranking)
# for i in range(scores.shape[0]):
#     label = config.id2label[ranking[i]]
#     score = scores[ranking[i]]
#     print(f"{i+1}) {label} {np.round(float(score), 4)}")
#response = max(f"{i+1}) {l} {np.round(float(s), 4)}")
#print(response)

def sentiment_analysis(review):
    inputs = tokenizer(review, return_tensors='pt')
    outputs = model(**inputs)
    predictions = outputs[0][0].detach().numpy()
    probabilities = softmax(predictions)
    prob_score = max(probabilities)
    ranking = np.argsort(probabilities)
    ranking = ranking[::-1]
    label = config.id2label[ranking[0]]
    return label, prob_score

#review = input('Enter a movie review: ')
# label, score = sentiment_analysis(review)
# print(f'The sentiment of the review is {label} with a probability of {score:.2f}.')

@app.route("/predict", methods=['POST'])
def predict():
    review = request.form['sentence']
    label, score = sentiment_analysis(review)

    response = {}
    response = {
        "sentiment": str(label),
        "score": (score)
    }
    return render_template("Index.html", Sentiment="The Sentiment and its confidence level is {}".format(response))
    #return render_template("Index.html", Submit=flask.jsonify(response))
    #return flask.jsonify(response)

if __name__ == "__main__":
    app.run(debug=True)